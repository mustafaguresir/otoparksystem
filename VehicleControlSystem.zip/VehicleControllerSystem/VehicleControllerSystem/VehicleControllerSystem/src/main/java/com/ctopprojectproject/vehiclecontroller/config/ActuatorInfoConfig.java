package com.ctopprojectproject.vehiclecontroller.config;

import java.util.Map;

import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ActuatorInfoConfig {

    @Bean
    public InfoContributor customInfoContributor() {
        // (Gereksinim 12) /actuator/info endpoint'ine projeyle ilintili veri ekler.
        return builder -> {
            builder.withDetail("project-details", Map.of(
                    "name", "Akıllı Otopark API",
                    "group", "com.ctopprojectproject",
                    "artifact", "vehiclecontroller",
                    "description", "Proje önerisi gerekliliklerini karşılayan API."
            ));
        };
    }
}