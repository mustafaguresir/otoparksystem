package com.ctopprojectproject.vehiclecontroller.entity;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "parking_floor")
public class ParkingFloor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String floorName;

    // GEREKSİNİM: DELETE hariç cascade + FetchType.EAGER
    @OneToMany(mappedBy = "parkingFloor", 
               cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
               fetch = FetchType.EAGER)//buradaki OneToMany ilişkisinde FetchType.EAGER kullandık ama default olrak FetchType.LAZY dır.
    private List<VehicleRecord> vehicles = new ArrayList<>();

    public ParkingFloor() {}
    public ParkingFloor(String floorName) { this.floorName = floorName; }

    public Long getId() { return id; }
    public String getFloorName() { return floorName; }
    public void setFloorName(String floorName) { this.floorName = floorName; }
    public List<VehicleRecord> getVehicles() { return vehicles; }
    public void setVehicles(List<VehicleRecord> vehicles) { this.vehicles = vehicles; }

    public void addVehicle(VehicleRecord vehicle) {
        vehicles.add(vehicle);
        vehicle.setParkingFloor(this);
    }
}