package com.ctopprojectproject.vehiclecontroller.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "vehicle_detail")
public class VehicleDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String color;
    private String model;

    @OneToOne(mappedBy = "vehicleDetail")
    private VehicleRecord vehicleRecord;

    public VehicleDetail() {}

    // GEREKSİNİM: Inverse side DELETE operasyonunda ilişki kırma
    @PreRemove
    public void preRemove() {
        if (this.vehicleRecord != null) {
            this.vehicleRecord.setVehicleDetail(null);
            this.vehicleRecord = null;
        }
    }

    public Long getId() { return id; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public VehicleRecord getVehicleRecord() { return vehicleRecord; }
    public void setVehicleRecord(VehicleRecord vehicleRecord) { this.vehicleRecord = vehicleRecord; }
}