package com.ctopprojectproject.vehiclecontroller.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// --- DÜZELTİLEN IMPORTLAR (HEPSİ ENTITY PAKETİNDEN) ---
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord;
import com.ctopprojectproject.vehiclecontroller.entity.VehicleDetail; // checkInWithDetails için lazım
import com.ctopprojectproject.vehiclecontroller.entity.ParkingFloor;
import com.ctopprojectproject.vehiclecontroller.entity.Member;
import com.ctopprojectproject.vehiclecontroller.entity.ServiceTag; // ARTIK ENTITY PAKETİNDE

import com.ctopprojectproject.vehiclecontroller.exception.VehicleNotFoundException;
import com.ctopprojectproject.vehiclecontroller.repository.VehicleDao;
import com.ctopprojectproject.vehiclecontroller.service.pricing.PricingStrategy;
import com.ctopprojectproject.vehiclecontroller.entity.Role;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class ParkingService {

    private final VehicleDao vehicleDao;
    private final PricingStrategy standardStrategy;
    
    @PersistenceContext
    private EntityManager entityManager;
    

    @Autowired
    public ParkingService(VehicleDao vehicleDao, 
                          @Qualifier("standardPricingStrategy") PricingStrategy standardStrategy) {
        this.vehicleDao = vehicleDao;
        this.standardStrategy = standardStrategy;
    }

    // --- OPERATÖR İŞLEMLERİ ---
    public List<Role> findAllRoles() {
        return vehicleDao.findAllRoles();
    }
    
 
    @Transactional
    public VehicleRecord checkIn(String plateNumber) {
        VehicleRecord record = new VehicleRecord();
        record.setPlateNumber(plateNumber);
        record.setCheckInTime(LocalDateTime.now());
        vehicleDao.save(record);
        return record;
    }

    @Transactional
    public VehicleRecord checkInWithDetails(String plate, String color, String model) {
        VehicleRecord record = new VehicleRecord();
        record.setPlateNumber(plate);
        record.setCheckInTime(LocalDateTime.now());

        VehicleDetail detail = new VehicleDetail();
        detail.setColor(color);
        detail.setModel(model);

        // İlişkiyi kuruyoruz
        record.setVehicleDetail(detail);
        // detail.setVehicleRecord(record); // OneToOne Cascade bunu halleder ama elle de set edilebilir

        vehicleDao.save(record);
        return record;
    }

    @Transactional
    public VehicleRecord checkOut(Long id) {
        VehicleRecord record = vehicleDao.findById(id);
        if (record == null) throw new VehicleNotFoundException("Araç bulunamadı: " + id);
        if (record.getCheckOutTime() != null) throw new IllegalStateException("Zaten çıkış yapmış.");

        LocalDateTime now = LocalDateTime.now();
        record.setCheckOutTime(now);
        long minutes = Duration.between(record.getCheckInTime(), now).toMinutes();
        
        double fee = standardStrategy.calculateFee(minutes);
        record.setTotalFee(fee);
        
        vehicleDao.save(record); // Update
        return record;
    }

    // --- ADMIN İŞLEMLERİ ---

    public List<VehicleRecord> getAllRecords() { return vehicleDao.findAll(); }
    
    public VehicleRecord getRecordById(Long id) { return vehicleDao.findById(id); }
    
    @Transactional
    public void deleteRecord(Long id) { vehicleDao.deleteById(id); }
    
    @Transactional
    public VehicleRecord updateRecord(Long id, VehicleRecord newRecord) {
        VehicleRecord existing = getRecordById(id);
        if(existing != null) {
            existing.setPlateNumber(newRecord.getPlateNumber());
            existing.setTotalFee(newRecord.getTotalFee());
            vehicleDao.save(existing);
        }
        return existing;
    }

    // --- KAT (FLOOR) İŞLEMLERİ ---
    
    public List<ParkingFloor> findAllFloors() {
        return vehicleDao.findAllFloors();
    }
    
    @Transactional
    public ParkingFloor saveFloor(ParkingFloor floor) {
        vehicleDao.saveFloor(floor);
        return floor;
    }
    
    @Transactional
    public void deleteFloor(Long id) {
        ParkingFloor f = vehicleDao.findFloorById(id);
        if(f != null) vehicleDao.deleteFloor(f);
    }

    @Transactional
    public ParkingFloor updateFloorName(Long id, String newName) {
        ParkingFloor f = vehicleDao.findFloorById(id);
        if(f != null && newName != null) {
            f.setFloorName(newName);
            vehicleDao.saveFloor(f);
        }
        return f;
    }
    
    // --- KULLANICI (MEMBER) İŞLEMLERİ ---
    
    public List<Member> findAllMembers() {
        return vehicleDao.findAllMembers();
    }
    
    @Transactional
    public void saveMember(Member member) {
        vehicleDao.saveMember(member);
    }

    @Transactional
    public void deleteMember(Long id) {
        Member m = entityManager.find(Member.class, id);
        if(m != null) entityManager.remove(m);
    }

    // --- HİZMET ETİKETİ (SERVICE TAG) METOTLARI ---
    
    public List<ServiceTag> findAllTags() {
        return entityManager.createQuery("FROM ServiceTag", ServiceTag.class).getResultList();
    }

    @Transactional
    public ServiceTag saveServiceTag(ServiceTag tag) {
        if(tag.getId() == null) entityManager.persist(tag);
        else entityManager.merge(tag);
        return tag;
    }

    // --- INIT DATA İÇİN ---
    @Transactional
    public void checkInDirect(VehicleRecord record) {
        vehicleDao.save(record);
    }


}