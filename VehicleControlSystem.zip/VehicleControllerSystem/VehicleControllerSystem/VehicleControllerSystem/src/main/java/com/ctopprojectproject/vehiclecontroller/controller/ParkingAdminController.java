
package com.ctopprojectproject.vehiclecontroller.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

// --- DÜZELTİLEN IMPORTLAR (ARADAKİ 'vehiclecontroller' KELİMESİNE DİKKAT) ---
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord;
import com.ctopprojectproject.vehiclecontroller.entity.ParkingFloor;
import com.ctopprojectproject.vehiclecontroller.entity.Member;
import com.ctopprojectproject.vehiclecontroller.entity.ServiceTag;

import com.ctopprojectproject.vehiclecontroller.service.ParkingService;
import com.ctopprojectproject.vehiclecontroller.service.ReportingService;

@RestController
@RequestMapping("/api/admin")
public class ParkingAdminController {

    private final ParkingService parkingService;
    private final ReportingService reportingService;
    private final PasswordEncoder passwordEncoder;

    @Value("${server.port}")
    private String serverPort;

    @Autowired
    public ParkingAdminController(
            ParkingService parkingService,
            @Lazy ReportingService reportingService,
            PasswordEncoder passwordEncoder) {

        this.parkingService = parkingService;
        this.reportingService = reportingService;
        this.passwordEncoder = passwordEncoder;
    }



    @GetMapping("/list")
    public List<VehicleRecord> getAllRecords() {
        return parkingService.getAllRecords();
    }

    @GetMapping("/{id}")
    public VehicleRecord getRecordById(@PathVariable Long id) {
        return parkingService.getRecordById(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecord(@PathVariable Long id) {
        parkingService.deleteRecord(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public VehicleRecord updateRecord(@PathVariable Long id, @RequestBody VehicleRecord record) {
        return parkingService.updateRecord(id, record);
    }

    // =========================================================
    // 2. KAT (FLOOR) İŞLEMLERİ
    // =========================================================

    @GetMapping("/floors")
    public List<ParkingFloor> getAllFloors() {
        return parkingService.findAllFloors();
    }

    @PostMapping("/floors")
    public ParkingFloor createFloor(@RequestBody ParkingFloor floor) {
        return parkingService.saveFloor(floor);
    }

    @DeleteMapping("/floors/{id}")
    public ResponseEntity<Void> deleteFloor(@PathVariable Long id) {
        parkingService.deleteFloor(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/floors/{id}")
    public ParkingFloor updateFloorName(@PathVariable Long id, @RequestBody Map<String, String> updates) {
        String newName = updates.get("floorName");
        return parkingService.updateFloorName(id, newName);
    }


    @GetMapping("/members")
    public List<Member> getAllMembers() {
        return parkingService.findAllMembers();
    }

    @PostMapping("/members")
    public ResponseEntity<Member> createMember(@RequestBody Member member) {
        member.setPassword(passwordEncoder.encode(member.getPassword()));
        parkingService.saveMember(member);
        return ResponseEntity.ok(member);
    }

    @DeleteMapping("/members/{id}")
    public ResponseEntity<Void> deleteMember(@PathVariable Long id) {
        parkingService.deleteMember(id);
        return ResponseEntity.noContent().build();
    }



    @GetMapping("/tags")
    public List<ServiceTag> getAllTags() {
        return parkingService.findAllTags();
    }

    @PostMapping("/tags")
    public ServiceTag createTag(@RequestBody ServiceTag tag) {
        return parkingService.saveServiceTag(tag);
    }



    @GetMapping("/port-info")
    public String getPortInfo() {
        return "Uygulama şu portta çalışıyor: " + serverPort;
    }

    @GetMapping("/report")
    public String getDailyReport() {
        return reportingService.generateDailyReport();
    }
}