package com.ctopprojectproject.vehiclecontroller.service.pricing;

/**
 * Alternatif ücretlendirme stratejisi.
 * @Qualifier ile seçilecek.
 */
public class PremiumPricingStrategy implements PricingStrategy {
    
    private static final double BASE_FEE = 50.0;
    private static final double HOURLY_FEE = 20.0;

    @Override
    public double calculateFee(long durationMinutes) {
        if (durationMinutes <= 0) return 0.0;
        
        double totalHours = Math.ceil(durationMinutes / 60.0);
        return BASE_FEE + (totalHours * HOURLY_FEE);
    }
}