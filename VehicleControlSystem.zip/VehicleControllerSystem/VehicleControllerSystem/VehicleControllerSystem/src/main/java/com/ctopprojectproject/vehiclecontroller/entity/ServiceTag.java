package com.ctopprojectproject.vehiclecontroller.entity; // PAKET İSMİ ENTITY OLMALI
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "service_tag")
public class ServiceTag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tagName;

    @ManyToMany(mappedBy = "serviceTags")
     
    private List<VehicleRecord> vehicles = new ArrayList<>();

    public ServiceTag() {}
    public ServiceTag(String tagName) { this.tagName = tagName; }

    public Long getId() { return id; }
    public String getTagName() { return tagName; }
    public void setTagName(String tagName) { this.tagName = tagName; }
    public List<VehicleRecord> getVehicles() { return vehicles; }
    public void setVehicles(List<VehicleRecord> vehicles) { this.vehicles = vehicles; }
}