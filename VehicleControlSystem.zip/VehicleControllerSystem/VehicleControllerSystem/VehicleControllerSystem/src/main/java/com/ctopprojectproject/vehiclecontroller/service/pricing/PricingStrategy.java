package com.ctopprojectproject.vehiclecontroller.service.pricing;

/**
 * Dinamik ücretlendirme için strateji arayüzü.
 */
public interface PricingStrategy {
    double calculateFee(long durationMinutes);
}