package com.ctopprojectproject.vehiclecontroller.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String roleName; // Örn: ROLE_ADMIN, ROLE_OPERATOR

    public Role() {}
    public Role(String roleName) { this.roleName = roleName; }

    public Long getId() { return id; }
    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }
}