package com.ctopprojectproject.vehiclecontroller.entity; // Paketi entity yaptık

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "vehicle_record")
public class VehicleRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String plateNumber;
    
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private Double totalFee;

    // --- İLİŞKİ 1: Detay (OneToOne) ---
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "vehicle_detail_id")
    private VehicleDetail vehicleDetail;

    @ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH})
    @JoinColumn(name = "parking_floor_id")
    private ParkingFloor parkingFloor;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
        name = "vehicle_service_tags",
        joinColumns = @JoinColumn(name = "vehicle_id"),
        inverseJoinColumns = @JoinColumn(name = "tag_id")
    )
    private List<ServiceTag> serviceTags = new ArrayList<>();

    public VehicleRecord() {}

    // --- GETTER VE SETTER METOTLARI ---

    public Long getId() { return id; }
    
    public String getPlateNumber() { return plateNumber; }
    public void setPlateNumber(String plateNumber) { this.plateNumber = plateNumber; }

    public LocalDateTime getCheckInTime() { return checkInTime; }
    public void setCheckInTime(LocalDateTime checkInTime) { this.checkInTime = checkInTime; }

    public LocalDateTime getCheckOutTime() { return checkOutTime; }
    public void setCheckOutTime(LocalDateTime checkOutTime) { this.checkOutTime = checkOutTime; }

    public Double getTotalFee() { return totalFee; }
    public void setTotalFee(Double totalFee) { this.totalFee = totalFee; }

    public VehicleDetail getVehicleDetail() { return vehicleDetail; }
    public void setVehicleDetail(VehicleDetail vehicleDetail) {
        this.vehicleDetail = vehicleDetail;
        if(vehicleDetail != null) vehicleDetail.setVehicleRecord(this);
    }

    // --- İŞTE BU METOD EKSİKTİ, O YÜZDEN HATA ALIYORDUNUZ ---
    public ParkingFloor getParkingFloor() { return parkingFloor; }
    public void setParkingFloor(ParkingFloor parkingFloor) { 
        this.parkingFloor = parkingFloor; 
    }

    public List<ServiceTag> getServiceTags() { return serviceTags; }
    public void setServiceTags(List<ServiceTag> serviceTags) { this.serviceTags = serviceTags; }

    public void addServiceTag(ServiceTag tag) {
        this.serviceTags.add(tag);
        tag.getVehicles().add(this);
    }
}