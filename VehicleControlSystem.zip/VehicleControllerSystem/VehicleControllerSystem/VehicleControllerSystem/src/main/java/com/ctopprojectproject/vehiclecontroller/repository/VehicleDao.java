package com.ctopprojectproject.vehiclecontroller.repository;

import java.util.List;

// --- DÜZELTİLEN IMPORT ---
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord; 
import com.ctopprojectproject.vehiclecontroller.entity.ParkingFloor;
import com.ctopprojectproject.vehiclecontroller.entity.Member;
import com.ctopprojectproject.vehiclecontroller.entity.Role;

public interface VehicleDao {

    void save(VehicleRecord vehicleRecord);
    VehicleRecord findById(Long id);
    List<VehicleRecord> findAll();
    void deleteById(Long id);
    List<ParkingFloor> findAllFloors();
    void saveFloor(ParkingFloor floor);
    void deleteFloor(ParkingFloor floor);
    ParkingFloor findFloorById(Long id);
    List<Role> findAllRoles();
    List<Member> findAllMembers();
    void saveMember(Member member);
    Role findRoleByName(String roleName);
    void saveRole(Role role);
    void saveMemberWithRole(String username, String password, String roleName);
}