

package com.ctopprojectproject.vehiclecontroller.controller;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// --- DÜZELTİLEN IMPORT (Entity klasöründen çağırıyoruz) ---
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord;

import com.ctopprojectproject.vehiclecontroller.service.ParkingService;

@RestController 
@RequestMapping("/api/operator") 
public class ParkingOperatorController {

    private final ParkingService parkingService;

    @Autowired
    public ParkingOperatorController(ParkingService parkingService) {
        this.parkingService = parkingService;
    }

    @PostMapping("/check-in")
    public ResponseEntity<VehicleRecord> checkIn(@RequestBody Map<String, String> body) {
        String plate = body.get("plateNumber");
        // Not: Basit checkIn yerine detaylı checkIn istenirse service metodunu güncelleyebilirsiniz.
        return new ResponseEntity<>(parkingService.checkIn(plate), HttpStatus.CREATED);
    }
    
    @PatchMapping("/check-out/{id}")
    public ResponseEntity<VehicleRecord> checkOut(@PathVariable Long id) { 
        return ResponseEntity.ok(parkingService.checkOut(id));
    }
}