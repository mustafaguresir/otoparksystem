package com.ctopprojectproject.vehiclecontroller.repository;

import java.util.List;
import org.springframework.stereotype.Repository;

// --- DÜZELTİLEN IMPORTLAR ---
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord;
import com.ctopprojectproject.vehiclecontroller.entity.ParkingFloor;
import com.ctopprojectproject.vehiclecontroller.entity.Member;
import com.ctopprojectproject.vehiclecontroller.entity.Role;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class VehicleDaoImpl implements VehicleDao {

    @PersistenceContext
    private EntityManager entityManager;

    // --- ARAÇ ---
    @Override
    public void save(VehicleRecord vehicleRecord) {
        if (vehicleRecord.getId() == null) {
            entityManager.persist(vehicleRecord);
        } else {
            entityManager.merge(vehicleRecord);
        }
    }

    @Override
    public VehicleRecord findById(Long id) {
        return entityManager.find(VehicleRecord.class, id);
    }

    @Override
    public List<VehicleRecord> findAll() {
        return entityManager.createQuery("from VehicleRecord", VehicleRecord.class).getResultList();
    }

    @Override
    public void deleteById(Long id) {
        VehicleRecord vehicle = findById(id);
        if (vehicle != null) {
            entityManager.remove(vehicle);
        }
    }
        @Override
    public List<Role> findAllRoles() {
        // Role tablosundaki TÜM verileri getirir
        return entityManager.createQuery("FROM Role", Role.class).getResultList();
    }

    // --- KAT ---
    @Override
    public List<ParkingFloor> findAllFloors() {
        return entityManager.createQuery("FROM ParkingFloor", ParkingFloor.class).getResultList();
    }

    @Override
    public void saveFloor(ParkingFloor floor) {
        if(floor.getId() == null) entityManager.persist(floor);
        else entityManager.merge(floor);
    }

    @Override
    public void deleteFloor(ParkingFloor floor) {
        if(entityManager.contains(floor)) entityManager.remove(floor);
        else entityManager.remove(entityManager.merge(floor));
    }

    @Override
    public ParkingFloor findFloorById(Long id) {
        return entityManager.find(ParkingFloor.class, id);
    }

    // --- ÜYE ---
    @Override
    public List<Member> findAllMembers() {
        return entityManager.createQuery("FROM Member", Member.class).getResultList();
    }

    @Override
    public void saveMember(Member member) {
        if(member.getId() == null) entityManager.persist(member);
        else entityManager.merge(member);
    }

@Override
public Role findRoleByName(String roleName) {
    try {
        return entityManager.createQuery("SELECT r FROM Role r WHERE r.roleName = :name", Role.class)
                            .setParameter("name", roleName)
                            .getSingleResult();
    } catch (jakarta.persistence.NoResultException e) {
        return null; // Rol yoksa null döner
    }
}

@Override
public void saveRole(Role role) {
    if (role.getId() == null) entityManager.persist(role);
    else entityManager.merge(role);
}
@Override
public void saveMemberWithRole(String username, String password, String roleName) {
    // Yeni bir Member oluştur
    Member member = new Member();
    member.setUsername(username);
    member.setPassword(password);
    member.setEnabled(true);

    // İlgili Role'u bul
    Role role = findRoleByName(roleName);
    if (role == null) {
        // Rol yoksa yeni bir rol oluştur
        role = new Role();
        role.setRoleName(roleName);
        saveRole(role);
    }

    // Role'u Member'a ekle
    member.getRoles().add(role);

    // Member'ı kaydet
    saveMember(member);
}




}