package com.ctopprojectproject.vehiclecontroller.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.sql.DataSource;

@Configuration
public class SecurityConfig {

    // Şifreleme Bean'i
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * İŞTE RESİMDEKİ JDBC KISMI BURASI!
     * Spring Security'ye diyoruz ki: "Kullanıcıları veritabanından bu SQL'lerle bul."
     */
    @Bean
    public UserDetailsManager userDetailsManager(DataSource dataSource) {
        JdbcUserDetailsManager jdbcManager = new JdbcUserDetailsManager(dataSource);

                jdbcManager.setUsersByUsernameQuery(
            "SELECT username, password, enabled FROM members WHERE username = ?"
        );

        jdbcManager.setAuthoritiesByUsernameQuery(
            "SELECT m.username, r.role_name " +
            "FROM members m " +
            "JOIN members_roles mr ON m.id = mr.member_id " +
            "JOIN roles r ON r.id = mr.role_id " +
            "WHERE m.username = ?"
        );

        return jdbcManager;
    }

    // Erişim Kuralları (Filtre Zinciri)
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(configurer ->
                configurer
                        // ADMIN ERIŞIMI
                        .requestMatchers(HttpMethod.POST, "/api/admin/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/admin/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/admin/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/admin/**").hasRole("ADMIN")

                        // OPERATOR ERIŞIMI (Admin de yapabilir)
                        .requestMatchers(HttpMethod.POST, "/api/operator/**").hasAnyRole("ADMIN", "OPERATOR")
                        .requestMatchers(HttpMethod.PUT, "/api/operator/**").hasAnyRole("ADMIN", "OPERATOR")

                        // HERKESİN GÖREBİLECEĞİ YERLER
                        .requestMatchers(HttpMethod.GET, "/api/viewer/**").permitAll()
                        
                        // Diğer tüm istekler kimlik doğrulaması istesin
                        .anyRequest().authenticated()
        );

        // HTTP Basic Auth kullan
        http.httpBasic(Customizer.withDefaults());

        // CSRF'yi kapat (Postman testleri için gerekli)
        http.csrf(csrf -> csrf.disable());

        return http.build();
    }
}