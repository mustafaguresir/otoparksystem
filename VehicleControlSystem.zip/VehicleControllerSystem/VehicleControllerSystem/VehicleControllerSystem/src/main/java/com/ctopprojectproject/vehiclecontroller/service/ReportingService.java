package com.ctopprojectproject.vehiclecontroller.service;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

@Service
@Lazy
public class ReportingService {

    public ReportingService() {
        System.out.println(">>> ReportingService YÜKLENİYOR (LAZY) <<<");
    }

    public String generateDailyReport() {
        return "Bugünkü Toplam Kazanç: 5000 TL (Rapor oluşturuldu)";
    }
}
