package com.ctopprojectproject.vehiclecontroller.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.ctopprojectproject.vehiclecontroller.service.pricing.PremiumPricingStrategy;
import com.ctopprojectproject.vehiclecontroller.service.pricing.PricingStrategy;
import com.ctopprojectproject.vehiclecontroller.service.pricing.StandardPricingStrategy; // (Gereksinim Anotasyonu)

@Configuration // (Gereksinim Anotasyonu)
public class PricingConfig {

    @Bean // (Gereksinim Anotasyonu)
    @Primary // (Gereksinim Anotasyonu)
    public PricingStrategy standardPricingStrategy() {
        return new StandardPricingStrategy();
    }

    @Bean(name = "premiumStrategy") // (Gereksinim: @Qualifier için)
    public PricingStrategy premiumPricingStrategy() {
        return new PremiumPricingStrategy();
    }
}