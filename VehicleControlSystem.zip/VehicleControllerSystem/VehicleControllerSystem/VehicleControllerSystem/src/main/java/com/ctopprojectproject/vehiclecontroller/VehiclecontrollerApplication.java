package com.ctopprojectproject.vehiclecontroller;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ctopprojectproject.vehiclecontroller.entity.Member;
import com.ctopprojectproject.vehiclecontroller.entity.Role;
import com.ctopprojectproject.vehiclecontroller.entity.ParkingFloor;
import com.ctopprojectproject.vehiclecontroller.entity.VehicleRecord;
import com.ctopprojectproject.vehiclecontroller.entity.VehicleDetail;
import com.ctopprojectproject.vehiclecontroller.entity.ServiceTag;

import com.ctopprojectproject.vehiclecontroller.service.ParkingService;

import java.util.List;
import java.time.LocalDateTime;

@SpringBootApplication
public class VehiclecontrollerApplication {

    public static void main(String[] args) {
        SpringApplication.run(VehiclecontrollerApplication.class, args);
    }

    @Autowired PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initData(ParkingService parkingService) {
        return args -> {
            // Hata Önleyici Kontrol
            try {
                if (!parkingService.findAllMembers().isEmpty()) {
                    System.out.println(">>> SISTEMDE VERI VAR. ATLANDI.");
                    return; 
                }
            } catch (Exception e) {
                System.out.println(">>> Kontrol hatası, devam ediliyor...");
            }

            System.out.println(">>> BAŞLANGIÇ VERİLERİ YÜKLENİYOR...");

            // 1. ROLLERİ OLUŞTURUYORUZ
            Role roleAdmin = new Role("ROLE_ADMIN");
            Role roleOp = new Role("ROLE_OPERATOR");
            Role roleViewer = new Role("ROLE_VIEWER");
            
            // 2. KULLANICILARI "NORMAL İSİMLERLE" OLUŞTURUYORUZ
            
            // KULLANICI 1: AHMET BEY (ADMİN)
            Member m1 = new Member();
            m1.setUsername("AhmetYilmaz");  // <-- Normal İsim
            m1.setPassword(passwordEncoder.encode("1234"));
            // DİKKAT: İŞTE BURADA ROLÜ BAĞLIYORUZ! (BAĞLAMAZSAK GİREMEZ)
            m1.setRoles(List.of(roleAdmin)); 
            parkingService.saveMember(m1);

            // KULLANICI 2: AYŞE HANIM (OPERATÖR)
            Member m2 = new Member();
            m2.setUsername("AyseDemir");    // <-- Normal İsim
            m2.setPassword(passwordEncoder.encode("1234"));
            // ROL BAĞLAMA İŞLEMİ:
            m2.setRoles(List.of(roleOp));
            parkingService.saveMember(m2);

            // KULLANICI 3: MEHMET BEY (İZLEYİCİ)
            Member m3 = new Member();
            m3.setUsername("MehmetKaya");   // <-- Normal İsim
            m3.setPassword(passwordEncoder.encode("1234"));
            // ROL BAĞLAMA İŞLEMİ:
            m3.setRoles(List.of(roleViewer));
            parkingService.saveMember(m3);

            // 3. KATLARI EKLE
            ParkingFloor floor1 = new ParkingFloor("Zemin Kat");
            ParkingFloor floor2 = new ParkingFloor("Teras Kat");
            parkingService.saveFloor(floor1);
            parkingService.saveFloor(floor2);

            // 4. HİZMETLERİ EKLE
            ServiceTag tagWash = new ServiceTag("Detaylı Temizlik");
            ServiceTag tagVip = new ServiceTag("Vale Hizmeti");
            parkingService.saveServiceTag(tagWash);
            parkingService.saveServiceTag(tagVip);

            // 5. ÖRNEK ARAÇ
            VehicleRecord v1 = new VehicleRecord();
            v1.setPlateNumber("34 TR 1923"); // Güzel bir plaka
            v1.setCheckInTime(LocalDateTime.now().minusHours(1)); 
            
            VehicleDetail d1 = new VehicleDetail();
            d1.setColor("Kırmızı");
            d1.setModel("TOGG T10X");
            
            v1.setVehicleDetail(d1); 
            floor1.addVehicle(v1);   
            v1.addServiceTag(tagVip);

            parkingService.checkInDirect(v1);

            System.out.println(">>> SİSTEM HAZIR! KULLANICILAR: AhmetYilmaz (Admin), AyseDemir (Operator), MehmetKaya (Viewer)");
        };
    }
}