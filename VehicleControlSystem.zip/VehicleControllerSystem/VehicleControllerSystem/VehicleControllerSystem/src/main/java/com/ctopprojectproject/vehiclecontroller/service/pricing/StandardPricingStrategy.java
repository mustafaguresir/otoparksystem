package com.ctopprojectproject.vehiclecontroller.service.pricing;

/**
 * Varsayılan (Primary) ücretlendirme stratejisi.
 * Formülü burada tanımlarız.
 */
public class StandardPricingStrategy implements PricingStrategy {

    // Formülümüzün sabitleri
    private static final double FIRST_HOUR_FEE = 15.0; // F_ilk (15 TL)
    private static final double HOURLY_FEE_AFTER_FIRST = 10.0; // F_sonraki (10 TL)

    /**
     * (Gereksinim Anotasyonu: @Transactional, @Service vb. ile dolaylı olarak kullanılır)
     * * Bu metot, ParkingService tarafından çağrıldığında
     * dinamik ücretlendirme formülünü uygular.
     * * @param durationMinutes Otoparkta kalınan toplam dakika (T)
     * @return Hesaplanan toplam ücret (Ücret)
     */
    @Override
    public double calculateFee(long durationMinutes) {
        
        // Araç 0 dakika veya daha az kaldıysa (hata durumu)
        if (durationMinutes <= 0) {
            return 0.0;
        }

        // --- DURUM 1: Eğer T <= 60 ise ---
        if (durationMinutes <= 60) {
            return FIRST_HOUR_FEE; // Sadece ilk saat ücretini (15 TL) döndür
        }

        // --- DURUM 2: Eğer T > 60 ise ---
        
        // 1. Kalan dakikaları hesapla (T - 60)
        double remainingMinutes = durationMinutes - 60;
        
        // 2. Kalan dakikaları saate çevir ve TAVANA YUVARLA (Math.ceil)
        // Örn: 1 dakika kalmışsa (1/60 = 0.016), bu 1.0'a yuvarlanır (1 saat sayılır)
        // Örn: 61 dakika kalmışsa (61/60 = 1.016), bu 2.0'a yuvarlanır (2 saat sayılır)
        double remainingHours = Math.ceil(remainingMinutes / 60.0);
        
        // 3. Ücreti hesapla: F_ilk + (KalanSaatler * F_sonraki)
        return FIRST_HOUR_FEE + (remainingHours * HOURLY_FEE_AFTER_FIRST);
    }
}